import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.json.JSONException;

/*Prompts user for email-id and product-id/product-name. Practically, this must be taken from the user as input
 * from a web page and stored in a database. A scheduler needs to run at a specific interval and pass the 
 * over to the Zappos program to find if any of a user's favorite product fall
 * below a desired percentage and then the user must be e-mailed about this information.
 * Just for demonstration purposes, this code also shows a raw scheduler that checks the database every 5 seconds for email-id to favorite product
 * pairs and mails the customers if their selections have dropped below a percentage. 
 * 
 */
public class Zappos {

	public static void main(String[] args) throws IOException, JSONException {

		try {
			//Configuration file
			Properties configFile = new Properties();
			InputStream input = new FileInputStream("config.properties");
			configFile.load(input);
			
			//Result from search storage
			ArrayList<Product> productDetails = new ArrayList<Product>();
			//To check for valid email entry
			boolean emailCheck = true;
			
			//Initializations
			String email = "";
			String product = "";
			String enterEmailMessage = configFile
					.getProperty("enter.email.message");
			String apiKey = configFile.getProperty("apiKey");
			
			Scanner in = new Scanner(System.in);

			//Accept email-id of the customer
			while (emailCheck) {
				System.out.println(enterEmailMessage);
				email = in.nextLine();
				//Validation of entered email
				EmailValidator emailValidator = new EmailValidator();
				if (emailValidator.validate(email)) {
					emailCheck = false;
				}
				enterEmailMessage = configFile
						.getProperty("enter.email.message.retry");
			}
			
			
			String productEntryMessage = configFile
					.getProperty("product.entry.message");
			System.out.println(productEntryMessage);
			product = in.nextLine();
			Integer perc = new Integer(configFile.getProperty("perc.20"));
			//Get search results for the user
			productDetails = Parser.parser(product, apiKey, perc);
			System.out.println("size = " + productDetails.size());
			
			//Initiate mail message creation and email if search returns any products
			if (productDetails.size() > 0) {
				Mail.messageFormatMail(
						configFile.getProperty("sender.username"), email,
						configFile.getProperty("informer.title"),
						productDetails);
			}

			// Scheduled job to check for price drop and email customer if any found
			Reminder schedule = new Reminder(5);
		} catch (AddressException e) {
			System.out.println("AddressException occured");
		} catch (MessagingException e) {
			System.out.println("MessagingException occured");
		} catch (IOException e) {
			System.out.println("IOException occured");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}