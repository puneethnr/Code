import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.json.JSONException;

public class Reminder {
	Timer timer;

	public Reminder(int seconds) {
		timer = new Timer();
		timer.schedule(new RemindTask(), 0, seconds * 1000);
	}

	class RemindTask extends TimerTask {
		public void run() {
			ArrayList<Product> productDetails = new ArrayList<Product>();

			// Connect to the database and extract all email-id and favorite
			// products
			// Append each product-id in the form of : 7564933,7590514,... and
			// store it in 'product'
			// Fetch 'email' from the database to send to
			// Call this method for every email-id in the database and their
			// corresponding favorites
			try {
				Properties configFile = new Properties();
				InputStream input = new FileInputStream("config.properties");
				configFile.load(input);
				
				productDetails = Parser.parser("7515478,8166134",
						"52ddafbe3ee659bad97fcce7c53592916a6bfd73", 20);

				if (productDetails.size() > 0) {
					Mail.messageFormatMail(
							configFile.getProperty("sender.username"),
							"ankush7.r@gmail.com",
							configFile.getProperty("informer.title"),
							productDetails);
				}

			} catch (JSONException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (AddressException e) {
				e.printStackTrace();
			} catch (MessagingException e) {
				e.printStackTrace();
			}
		}
	}
}