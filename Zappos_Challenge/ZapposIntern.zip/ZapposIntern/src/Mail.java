import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Security;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.sun.mail.smtp.SMTPTransport;

public class Mail {

	static void messageFormatMail(String username, String email, String title,
			ArrayList<Product> productDetails) throws AddressException,
			MessagingException, IOException {

		String message = messageMaker(productDetails);
		Mail.Send(username, email, "", title, message);

	}

	//Takes search results and converts them to html specific content for the email to the customer
	private static String messageMaker(ArrayList<Product> productDetails)
			throws IOException {

		Properties configFile = new Properties();
		InputStream input = new FileInputStream("config.properties");
		configFile.load(input);
		String imageWidth = configFile.getProperty("image.width");
		String imageHeight = configFile.getProperty("image.height");
		String products = "";
		for (Product product : productDetails) {
			products += "<a href=" + product.productUrl + "><img src="
					+ product.imageUrl + " alt=" + product.productName
					+ " width=" + imageWidth + " height=" + imageHeight
					+ "></a><br/>New price : " + product.price
					+ "<br/>Original price : <strike>" + product.originalPrice
					+ "</strike><br/>";
		}

		return "<div>" + products + "</div>";
	}

	public static void Send(final String username, String recipientEmail,
			String ccEmail, String title, String message)
			throws AddressException, MessagingException, IOException {
		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

		// Get a Properties object
		Properties props = System.getProperties();
		props.setProperty("mail.smtps.host", "smtp.gmail.com");
		props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
		props.setProperty("mail.smtp.socketFactory.fallback", "false");
		props.setProperty("mail.smtp.port", "465");
		props.setProperty("mail.smtp.socketFactory.port", "465");
		props.setProperty("mail.smtps.auth", "true");
		props.put("mail.smtps.quitwait", "false");

		Session session = Session.getInstance(props, null);

		// -- Create a new message --
		final MimeMessage msg = new MimeMessage(session);

		// -- Set the FROM and TO fields --
		msg.setFrom(new InternetAddress(username + "@gmail.com"));
		msg.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(recipientEmail, false));

		if (ccEmail.length() > 0) {
			msg.setRecipients(Message.RecipientType.CC,
					InternetAddress.parse(ccEmail, false));
		}

		msg.setSubject(title);
		msg.setContent(message, "text/html; charset=utf-8");
		msg.setSentDate(new Date());

		SMTPTransport t = (SMTPTransport) session.getTransport("smtps");

		Properties configFile = new Properties();
		InputStream input = new FileInputStream("config.properties");
		configFile.load(input);

		t.connect("smtp.gmail.com", username,
				configFile.getProperty("sender.password"));
		t.sendMessage(msg, msg.getAllRecipients());
		t.close();
	}
}