import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Parser {

	// reads all characters from the bufferedReader and returns them as a string
	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	// Interact with api and return search result json
	public static JSONObject readJsonFromUrl(String url) throws IOException,
			JSONException {
		try {
			InputStream is = new URL(url).openStream();

			BufferedReader rd = new BufferedReader(new InputStreamReader(is,
					Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			is.close();
			JSONObject json = new JSONObject(jsonText);
			return json;
		} catch (IOException e) {
			throw e;
		} catch (JSONException e) {
			throw e;
		}
	}

	public static ArrayList<Product> parser(String prod, String apiKey,
			Integer perc) throws JSONException, IOException {
		try {
			
			//Check if productId/productName entered by user
			boolean productIdEntered = false;
			if (prod.matches(".*\\d.*")) {
				productIdEntered = true;
			}

			ArrayList<Product> products = new ArrayList<Product>();
			JSONObject details = new JSONObject();
			
			//API interaction
			if (productIdEntered) {
				details = readJsonFromUrl("http://api.zappos.com/Product/"
						+ prod + "?includes=[%22styles%22]&key=" + apiKey);

			} else {
				details = readJsonFromUrl("http://api.zappos.com/Search?term="
						+ prod + "&key=" + apiKey);
			}
			
			//Parse JSON for search results and return them as a list of products
			Integer statusCode = new Integer((String) details.get("statusCode"));
			if (productIdEntered && (statusCode == 200)) {

				JSONArray productDetails = (JSONArray) details.get("product");
				for (int z = 0; z < productDetails.length(); z++) {
					JSONArray stylesArray = (JSONArray) (((JSONObject) productDetails
							.get(z)).get("styles"));
					String productId = (String) (((JSONObject) productDetails
							.get(z)).get("productId"));
					String productName = (String) (((JSONObject) productDetails
							.get(z)).get("productName"));

					for (int index = 0; index < stylesArray.length(); index++) {

						JSONObject styleDetails = (JSONObject) stylesArray
								.get(index);

						String stylePercOff = (String) styleDetails
								.get("percentOff");
						stylePercOff = stylePercOff.substring(0,
								stylePercOff.length() - 1);
						Integer percOff = new Integer(stylePercOff);

						if (percOff >= perc) {
							String stylePrice = (String) styleDetails
									.get("price");
							String styleOriginalPrice = (String) styleDetails
									.get("originalPrice");
							String styleImageUrl = (String) styleDetails
									.get("imageUrl");
							String styleProductUrl = (String) styleDetails
									.get("productUrl");
							Product product = new Product(stylePrice,
									styleOriginalPrice, styleImageUrl,
									styleProductUrl, productId, productName);
							products.add(product);
						}
					}
				}
			} else {
				if (statusCode == 200) {
					JSONArray stylesArray = (JSONArray) details.get("results");
					for (int index = 0; index < stylesArray.length(); index++) {

						JSONObject styleDetails = (JSONObject) stylesArray
								.get(index);
						String productId = (String) styleDetails
								.get("productId");
						String productName = (String) styleDetails
								.get("productName");
						String stylePercOff = (String) styleDetails
								.get("percentOff");
						stylePercOff = stylePercOff.substring(0,
								stylePercOff.length() - 1);
						Integer percOff = new Integer(stylePercOff);

						if (percOff >= perc) {
							String stylePrice = (String) styleDetails
									.get("price");
							String styleOriginalPrice = (String) styleDetails
									.get("originalPrice");
							String styleImageUrl = (String) styleDetails
									.get("thumbnailImageUrl");
							String styleProductUrl = (String) styleDetails
									.get("productUrl");
							Product product = new Product(stylePrice,
									styleOriginalPrice, styleImageUrl,
									styleProductUrl, productId, productName);
							products.add(product);
						}

					}

				}
			}
			return products;
		} catch (JSONException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		}
	}

}
