public class Product {

	String price;
	String originalPrice;
	String imageUrl;
	String productUrl;
	String productId;
	String productName;

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getOriginalPrice() {
		return originalPrice;
	}

	public void setOriginalPrice(String originalPrice) {
		this.originalPrice = originalPrice;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getProductUrl() {
		return productUrl;
	}

	public void setProductUrl(String productUrl) {
		this.productUrl = productUrl;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	Product(String price, String originalPrice, String imageUrl,
			String productUrl, String productId, String productName) {
		this.price = price;
		this.originalPrice = originalPrice;
		this.imageUrl = imageUrl;
		this.productUrl = productUrl;
		this.productName = productName;
	}

}
